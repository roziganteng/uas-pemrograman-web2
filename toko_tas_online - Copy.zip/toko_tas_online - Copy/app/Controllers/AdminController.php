<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    public function index()
    {
        return view('admin/dashboard');
    }

    public function daftarTas()
    {
        $tasModel = model('TasModel');

        $data['tas'] = $tasModel->findAll();
        return view('admin/daftar-tas', $data);
    }

    public function daftarTasTambah()
    {
        return view('admin/daftar-tas-tambah');
    }
    
    public function createTas()
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('gambar');

        if ($file && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        $tasModel = model('TasModel');

        if ($tasModel->insert($data, false)) {
            return redirect()->to('admin/daftar-tas')->with('berhasil', 'Data berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-tas')->with('gagal', 'Data gagal disimpan!');
        }
    }

    public function daftarTasEdit($id)
    {
        $tasModel = model('TasModel');
        $data['tas'] = $tasModel->find($id);

        if (!$data['tas']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Data tas dengan ID $id tidak ditemukan");
        }

        return view('admin/daftar-tas-edit', $data);
    }

    public function daftarTasUpdate($id)
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('gambar');

        if ($file && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['gambar'] = $path;
        }

        $tasModel = model('TasModel');

        if ($tasModel->update($id, $data)) {
            return redirect()->to('admin/daftar-tas')->with('berhasil', 'Data berhasil diupdate!');
        } else {
            return redirect()->to('admin/daftar-tas')->with('gagal', 'Data gagal diupdate!');
        }
    }

    public function hapusTas($id)
    {
        $tasModel = model('TasModel');

        if ($tasModel->delete($id)) {
            return redirect()->to('admin/daftar-tas')->with('berhasil', 'Data berhasil dihapus!');
        } else {
            return redirect()->to('admin/daftar-tas')->with('gagal', 'Data gagal dihapus!');
        }
    }

    public function transaksi()
    {
        return view('admin/transaksi');
    }

    public function transaksiUbahStatus()
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus()
    {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan()
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus()
    {
        return view('admin/pelanggan-hapus');
    }
}