<?php

namespace App\Models;

use CodeIgniter\Model;

class TasModel extends Model
{
    protected $table            = 'tas';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = ["nama", "merek", "spesifikasi", "tahun_rilis", "gambar", "harga"];

    protected bool $allowEmptyInserts = false;
    protected bool $updateOnlyChanged = true;

    protected array $casts = [
        'tahun_rilis' => 'integer', // Misalnya, jika tahun rilis adalah integer
        'harga' => 'float', // Jika harga adalah float
    ];

    // Dates
    protected $useTimestamps = true; // Mengaktifkan timestamps
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    // Validation
    protected $validationRules = [
        'nama' => 'required|min_length[3]',
        'merek' => 'required',
        'spesifikasi' => 'required',
        'tahun_rilis' => 'required|integer',
        'gambar' => 'permit_empty|is_image[gambar]', // Validasi gambar
        'harga' => 'required|decimal' // Validasi harga
    ];
    
    protected $validationMessages = [
        'nama' => [
            'required' => 'Nama tas harus diisi.',
            'min_length' => 'Nama tas minimal 3 karakter.'
        ],
        'merek' => [
            'required' => 'Merek harus diisi.'
        ],
        'spesifikasi' => [
            'required' => 'Spesifikasi harus diisi.'
        ],
        'tahun_rilis' => [
            'required' => 'Tahun rilis harus diisi.',
            'integer' => 'Tahun rilis harus berupa angka.'
        ],
        'gambar' => [
            'is_image' => 'File yang diupload harus berupa gambar.'
        ],
        'harga' => [
            'required' => 'Harga harus diisi.',
            'decimal' => 'Harga harus berupa angka desimal.'
        ]
    ];
    
    protected $skipValidation = false; // Tidak melewatkan validasi

    // Callbacks
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];
}